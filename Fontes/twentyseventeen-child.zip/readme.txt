Twenty Seventeen Child Theme

A ready to modify bare-bones child theme for use with Twenty Seventeen Theme.

To use this Child Theme, you must have Twenty Seventeen parent theme installed.

For more information about Twenty Seventeen Child Theme please go to:
http://hyperlinkcode.com/blog/twenty-seventeen-child-theme/


For more information about Twenty Seventeen parent theme please go to:
https://wordpress.org/themes/twentyseventeen/

Handy color charts for webmasters:
http://www.html-color-names.com
http://www.htmlcolorcodes.org
==
Installation
==


1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.


2. Click 'Upload Theme'.

3. Click 'Choose File' and browse to twentyseventeen-child.zip on your hard drive and select it.

4. Once you have selected twentyseventeen-child.zip, click 'Install Now'

5. Click on the 'Activate' button to use your new theme right away.



6. Navigate to Appearance > Editor in your WordPress admin panel to add custom modifications.
==
Copyright
==
Twenty Seventeen Child Theme, Copyright 2017 Ed Zivkovic and HyperlinkCode.com

==
Twenty Seventeen Child Theme is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or 
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details: http://www.gnu.org/licenses/gpl-2.0.html
==

More free Child Themes:
http://hyperlinkcode.com/blog/category/free-downloads/

http://www.ezau.com/topic/steal-my-stuff

Please join the blog updates mailing list to be informed when new content is published.

Best regards,

Ed Zivkovic
--
http://www.ezau.com
http://HyperlinkCode.com
